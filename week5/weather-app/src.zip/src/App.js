import React, { useState, useEffect } from 'react';

function App() {
  
  const [weatherData, setWeatherData] = useState(null);

  
  useEffect(() => {
    
    fetch('https://mm214.com/demo.php')  
      .then(response => response.json())  
      .then(data => {
        console.log(data);  
        setWeatherData(data);  
      })
      .catch(error => console.error('Error fetching data:', error));  
  }, []);  

  
  if (!weatherData) {
    return <div>Loading...</div>;
  }

  
  const cityName = weatherData.name;
  const description = weatherData.weather[0].description;
  const temperature = (weatherData.main.temp - 273.15).toFixed(2);  
  const humidity = weatherData.main.humidity;
  const windSpeed = weatherData.wind.speed;

  return (
    <div className="App">
      <h1>Weather in {cityName}</h1>
      <p>Description: {description}</p>
      <p>Temperature: {temperature}°C</p>
      <p>Humidity: {humidity}%</p>
      <p>Wind Speed: {windSpeed} m/s</p>
    </div>
  );
}

export default App;

