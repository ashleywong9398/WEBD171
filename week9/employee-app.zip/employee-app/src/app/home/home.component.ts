import { Component } from '@angular/core';

@Component({
  selector: 'app-home',
  template: `
    <p style="text-align: center;">home work!</p>
  `,
  standalone: true
})
export class HomeComponent { }
