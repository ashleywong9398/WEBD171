import { Component } from '@angular/core';

@Component({
  selector: 'app-employee',
  template: ` <p style="text-align: center;">employee work!</p>`,
  standalone: true
})
export class EmployeeComponent {}
