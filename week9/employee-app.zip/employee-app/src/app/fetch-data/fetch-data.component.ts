import { Component } from '@angular/core';

@Component({
  selector: 'app-fetch-data',
  template: `<p style="text-align: center;">fetch-data work!</p>`,
  standalone: true
})
export class FetchDataComponent {}

