import React from 'react';

function UserInfo() {
  return (
    <div>
      <img src="https://i.imgur.com/OH7dtc0.png" alt="Ironhacker" />
      <p>Ironhacker</p>
    </div>
  );
}

export default UserInfo;
