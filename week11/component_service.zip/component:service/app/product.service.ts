export class ProductService{
    getProducts() : string[] {
        return ["Learning Angular","Pro TypeScript","ASP.NET"];
    }
}
