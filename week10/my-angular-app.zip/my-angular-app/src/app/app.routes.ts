// src/app/app.routes.ts
import { Routes } from '@angular/router';
import { HomeComponent } from './home.component';
import { UserComponent } from './user.component';

export const routes: Routes = [
  { path: '', component: HomeComponent },  // 默认路径指向 HomeComponent
  { path: 'user', component: UserComponent }  // '/user' 路径指向 UserComponent
];
