// src/app/user.component.ts
import { Component } from '@angular/core';

@Component({
  selector: 'app-user',
  template: `<h2>Welcome to the User Page!</h2>`,
  standalone: true
})
export class UserComponent { }
